var level = 1;
var lastChoice = 0;

function generate() {
    if(level === 1) {
        let animal  = ["Sloth", "Cat", "Bear", "Pangolin"];
        var ran1 = Math.floor(Math.random() * 4);
        document.getElementById("gen").innerHTML = animal[ran1];
        lastChoice = ran1;
    } else if (level === 2) {
        let similar = [
            ["Bed", "Trees", "Heat", "Running"], 
            ["Lions", "Destruction", "Dog", "Big"], 
            ["Attack", "Survival", "Lazy", "Small"], 
            ["In Danger", "Spinning", "Destructive", "Day"]];
        var ran2 = Math.floor(Math.random() * 4);
        document.getElementById("gen").innerHTML = similar[lastChoice][ran2];
        lastChoice = ran2;
    }
}
function next() {
    level += 1;
}